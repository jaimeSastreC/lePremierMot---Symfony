
True Type Font: Modern Sans Serif 7 version 1.0


EULA
-==-
The font Modern Sans Serif 7 is freeware for home using only.


DESCRIPTION
-=========-
Original sans serif font. Cyrillic code page is supported.

Files in modern_sans_serif_7.zip:
       	readme.txt     				this file;
        modern_sans_serif_7.ttf 		regular font;
	modern_sans_serif_7_screen.png		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.

Use this link to buy the license ($24.95): http://store.esellerate.net/s.aspx?s=STR0331655240
Please enter font name in web form.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: January 20 2014